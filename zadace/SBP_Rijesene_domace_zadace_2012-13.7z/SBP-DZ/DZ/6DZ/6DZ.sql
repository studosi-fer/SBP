CREATE database testTran IN dbspace1 WITH LOG; 
DATABASE testTran;

CREATE TABLE racun ( 
   sifRacun    INTEGER      NOT NULL 
 , stanje      DECIMAL(9,2) NOT NULL 
 , dopustMinus DECIMAL(9,2) NOT NULL 
 , PRIMARY KEY (sifRacun)            CONSTRAINT pkRacun 
 , CHECK (stanje + dopustMinus >= 0) CONSTRAINT chkRacunStanje  
); 

CREATE TABLE promet ( 
   sifPromet  SERIAL       NOT NULL 
 , sifRacun   INTEGER      NOT NULL 
 , iznos      DECIMAL(9,2) NOT NULL 
 , PRIMARY KEY (sifPromet)          CONSTRAINT pkPromet 
 , FOREIGN KEY (sifRacun)  
        REFERENCES racun (sifRacun) CONSTRAINT fkPrometRacun 
); 

BEGIN WORK;    
INSERT INTO racun VALUES (1, 100.00, 200.00); 
INSERT INTO racun VALUES (2, 500.00, 500.00); 
COMMIT WORK;
--6.2
BEGIN WORK;   
INSERT INTO racun VALUES (3, 700.00, 100.00); 
SELECT * FROM racun; 
ROLLBACK WORK; 
SELECT * FROM racun;
-- 6.3
BEGIN WORK; 
BEGIN WORK;

ROLLBACK WORK;
-- 6.4
BEGIN WORK;  
INSERT INTO racun VALUES (3, 700.00, 100.00); 
SELECT * FROM racun; 

SELECT * FROM racun; 
-- 6.5
DELETE FROM promet WHERE 1=1; 
DELETE FROM racun WHERE 1=1; 
INSERT INTO racun VALUES (1, 100.00, 1000.00); 
INSERT INTO racun VALUES (2, 100.00, 0.00); 
INSERT INTO racun VALUES (3, 100.00, 1000.00);

UPDATE racun SET stanje = stanje - 1000.00 WHERE sifRacun IN (1, 2, 3);

SELECT * FROM racun;

UPDATE racun SET stanje = stanje - 1000.00 WHERE sifRacun IN (1, 2, 3);

SELECT * FROM racun;
-- 6.6
DELETE FROM promet WHERE 1=1; 
DELETE FROM racun WHERE 1=1; 
INSERT INTO racun VALUES (1, 100.00, 200.00); 
INSERT INTO racun VALUES (2, 500.00, 500.00); 

BEGIN WORK; 
SET CONSTRAINTS chkRacunStanje DEFERRED; 
UPDATE racun SET stanje = stanje - 50000.00 WHERE sifRacun = 1; 
SELECT * FROM racun;  -- ra�un sa �ifrom 1 je neispravan. Kako je to mogu�e? 
UPDATE racun SET stanje = stanje + 49950.00 WHERE sifRacun = 1; 
COMMIT WORK; 

SELECT * FROM racun;

BEGIN WORK; 
SET CONSTRAINTS chkRacunStanje DEFERRED; 
UPDATE racun SET stanje = stanje - 50.00 WHERE sifRacun = 1; 
UPDATE racun SET stanje = stanje - 500.00 WHERE sifRacun = 1; 
UPDATE racun SET stanje = stanje - 5000.00 WHERE sifRacun = 1; 
COMMIT WORK; 

SELECT * FROM racun;

-- 6.7
CREATE PROCEDURE unosPromet(pSifRacun LIKE promet.sifRacun 
                          , pIznos LIKE promet.iznos) 
   DEFINE sqle, isame INTEGER; 
   DEFINE errdata CHAR(80); 
   ON EXCEPTION SET sqle, isame, errdata 
      ROLLBACK WORK; 
      IF sqle = -530 AND errdata LIKE '%chkracunstanje%' THEN 
         RAISE EXCEPTION -746, 0, 'Nedopu�ten minus'; 
      ELSE 
         RAISE EXCEPTION sqle, isame, errdata; 
      END IF 
   END EXCEPTION; 
   BEGIN WORK; 
   INSERT INTO promet VALUES (0, pSifRacun, pIznos); 
   UPDATE racun SET stanje = stanje + pIznos  
      WHERE sifRacun = pSifRacun; 
   COMMIT WORK; 
END PROCEDURE; 

DELETE FROM promet WHERE 1=1; 
DELETE FROM racun WHERE 1=1; 
INSERT INTO racun VALUES (1, 100.00, 200.00); 
INSERT INTO racun VALUES (2, 500.00, 500.00); 

EXECUTE PROCEDURE unosPromet(2, -1000.00);
EXECUTE PROCEDURE unosPromet(1, -500.00);
EXECUTE PROCEDURE unosPromet(3, 200.00);
BEGIN WORK; 
     EXECUTE PROCEDURE unosPromet(1, 100.00); 
	 
-- 6.8
CREATE TABLE tab1 ( 
  rbr    INTEGER      NOT NULL 
, iznos  INTEGER      NOT NULL 
, PRIMARY KEY (rbr)    CONSTRAINT pkTab1 
); 
INSERT INTO tab1 VALUES (2, 20); 
INSERT INTO tab1 VALUES (3, 30); 
INSERT INTO tab1 VALUES (4, 40); 
INSERT INTO tab1 VALUES (5, 50); 
CREATE PROCEDURE raiseExcDelTab1 (rbr INTEGER)  
   RAISE EXCEPTION -746, 0, 'Zapis ' || rbr || ' se ne smije brisati'; 
END PROCEDURE; 
CREATE TRIGGER delTab1  
   DELETE ON tab1 
   REFERENCING OLD AS brisan 
   FOR EACH ROW 
   WHEN (MOD(brisan.rbr, 3) = 0) 
      (EXECUTE PROCEDURE raiseExcDelTab1(brisan.rbr)); 
  
CREATE TABLE tab2 ( 
   rbr    INTEGER      NOT NULL 
 , iznos  INTEGER      NOT NULL 
 , PRIMARY KEY (rbr)    CONSTRAINT pkTab2 
); 

INSERT INTO tab2 VALUES (5, 1000); 

select * from tab1;
select * from tab2;

CREATE PROCEDURE prebaci1() 
   ON EXCEPTION 
      -- nista, nastavi sa sljedecom naredbom 
   END EXCEPTION WITH RESUME 
   INSERT INTO tab2 SELECT * FROM tab1; 
   DELETE FROM tab1 WHERE 1=1; 
END PROCEDURE; 

execute procedure prebaci1();
select * from tab1;
select * from tab2;

CREATE PROCEDURE prebaci2() 
   DEFINE p_rbr INTEGER; 
   DEFINE p_iznos INTEGER; 
   FOREACH SELECT * INTO p_rbr, p_iznos FROM tab1 ORDER BY rbr 
      ON EXCEPTION 
         -- nista, nastavi sa sljedecom n-torkom 
      END EXCEPTION 
      INSERT INTO tab2 VALUES(p_rbr, p_iznos); 
      DELETE FROM tab1 WHERE rbr = p_rbr; 
   END FOREACH 
END PROCEDURE;

execute procedure prebaci2();
select * from tab1;
select * from tab2;

-- ponovno stvaram
CREATE PROCEDURE prebaci () 
   DEFINE p_rbr INTEGER; 
   DEFINE p_iznos INTEGER; 
   FOREACH WITH HOLD SELECT * INTO p_rbr, p_iznos FROM tab1 ORDER BY rbr 
      ON EXCEPTION 
         ROLLBACK WORK; 
      END EXCEPTION 
      BEGIN WORK; 
      INSERT INTO tab2 VALUES(p_rbr, p_iznos); 
      DELETE FROM tab1 WHERE rbr = p_rbr; 
      COMMIT WORK; 
   END FOREACH 
END PROCEDURE; 

execute procedure prebaci();
select * from tab1;
select * from tab2;
-- 6.9
DELETE FROM promet WHERE 1=1; 
DELETE FROM racun WHERE 1=1; 
INSERT INTO racun VALUES (1, 100.00, 200.00); 
INSERT INTO racun VALUES (2, 500.00, 500.00); 

-- ostatak preko komande linije
-- 6.10
DELETE FROM promet WHERE 1=1; 
DELETE FROM racun WHERE 1=1; 
INSERT INTO racun VALUES (1, 100.00, 200.00); 
INSERT INTO racun VALUES (2, 500.00, 500.00); 
-- ostatak preko komande linije
