CREATE database testOptim1 IN dbspace1; 
DATABASE testOptim1;

CREATE TABLE mjesto1 ( 
  pbr            INTEGER     NOT NULL  
, nazMjesto      NCHAR(100)  NOT NULL  
, brojStan       INTEGER     NOT NULL 
, brojLuka       INTEGER     NOT NULL 
) EXTENT SIZE 8000 NEXT SIZE 4000; 

CREATE TABLE mjesto2 ( 
  pbr            INTEGER     NOT NULL  
, nazMjesto      NCHAR(100)  NOT NULL  
, brojStan       INTEGER     NOT NULL 
, brojLuka       INTEGER     NOT NULL 
) EXTENT SIZE 8000 NEXT SIZE 4000; 

CREATE TABLE mjesto3 ( 
  pbr            INTEGER     NOT NULL  
, nazMjesto      NCHAR(100)  NOT NULL  
, brojStan       INTEGER     NOT NULL 
, brojLuka       INTEGER     NOT NULL 
) EXTENT SIZE 8000 NEXT SIZE 4000;
 
CREATE TABLE mjestoInternac ( 
  oznDrz         CHAR(2)     NOT NULL 
, pbr            INTEGER     NOT NULL  
, nazMjesto      NCHAR(100)  NOT NULL 
, brojStan       INTEGER     NOT NULL   
) EXTENT SIZE 20000 NEXT SIZE 10000; 

CREATE PROCEDURE srand (newSeed INTEGER) 
   DEFINE GLOBAL xRand INTEGER DEFAULT 1; 
   LET xRand = newSeed;  
END PROCEDURE;
 
CREATE FUNCTION rand () RETURNING INTEGER 
   DEFINE GLOBAL xRand INTEGER DEFAULT 1; 
   DEFINE GLOBAL a INTEGER DEFAULT 16807; 
   DEFINE GLOBAL c INTEGER DEFAULT 0; 
   DEFINE GLOBAL m INTEGER DEFAULT 2147483647; 
   LET xRand = MOD(a * xRand + c, m); 
   RETURN xRand; 
END FUNCTION; 

CREATE FUNCTION genNiz (lgth INTEGER) RETURNING CHAR(100) 
   DEFINE GLOBAL abeceda CHAR(26) DEFAULT 'abcdefghijklmnopqrstuvwxyz'; 
   DEFINE niz CHAR(100); 
   DEFINE i INTEGER; 
   LET niz = UPPER(SUBSTRING(abeceda FROM MOD(rand(), 26) + 1 FOR 1)); 
   FOR i = 2 TO lgth 
       LET niz = TRIM(niz) || SUBSTRING(abeceda FROM MOD(rand(), 26) + 1 FOR 1); 
   END FOR 
   RETURN niz; 
END FUNCTION; 

CREATE PROCEDURE genData () 
   DEFINE i, j INTEGER; 
   DELETE FROM mjesto1; 
   DELETE FROM mjesto2; 
   DELETE FROM mjestoInternac;    CALL srand(1234); 
   FOR i = 10000 TO 40000 
      INSERT INTO mjesto1  
        VALUES(i+10000 
             , genNiz(2 + MOD(rand(), 12)) 
             , MOD(rand(), 10) * 10000 + MOD(rand(), 10)*1000 + MOD(rand(), 10)*100 
             , 0);  
      INSERT INTO mjesto2  
        VALUES(i+10000 
             , genNiz(2 + MOD(rand(), 12))  
             , MOD(rand(), 10) * 10000 + MOD(rand(), 10)*1000 + MOD(rand(), 10) 
             , 0);  
      FOR j = 1 TO 5 
         INSERT INTO mjestoInternac  
            VALUES(CASE MOD(j, 5) 
                      WHEN 0 THEN 'hr' 
                      WHEN 1 THEN 'fr' 
                      WHEN 2 THEN 'ge' 
                      WHEN 3 THEN 'us' 
                      WHEN 4 THEN 'gb' 
                   END 
                 , i+10000 
                 , genNiz(2 + MOD(rand(), 12)) 
                 , MOD(rand(), 10) * 10000 + MOD(rand(), 10)*1000 + MOD(rand(), 
10)*100); 
      END FOR 
   END FOR; 
   UPDATE mjesto1 SET brojLuka = 
       CASE  
          WHEN MOD(pbr, 13) = 0 THEN 1 
          WHEN MOD(pbr, 23) = 0 THEN 2 
          WHEN MOD(pbr, 31) = 0 THEN 3 
          WHEN MOD(pbr, 127) = 0 THEN 4 
          WHEN MOD(pbr, 313) = 0 THEN 5 
          WHEN MOD(pbr, 1777) = 0 THEN 6 
          WHEN MOD(pbr, 6823) = 0 THEN 7 
          WHEN MOD(pbr, 7919) = 0 THEN 8 
          WHEN pbr = 30000 THEN 9 
          ELSE 0 
        END 
      WHERE 1=1; 
   UPDATE mjesto2 SET brojLuka = 
       CASE  
          WHEN MOD(pbr, 13) = 0 THEN 1 
          WHEN MOD(pbr, 23) = 0 THEN 2 
          WHEN MOD(pbr, 31) = 0 THEN 3 
          WHEN MOD(pbr, 127) = 0 THEN 4 
          WHEN MOD(pbr, 313) = 0 THEN 5 
          WHEN MOD(pbr, 1777) = 0 THEN 6 
          WHEN MOD(pbr, 6823) = 0 THEN 7 
          WHEN MOD(pbr, 7919) = 0 THEN 8 
          WHEN pbr = 30000 THEN 9 
          ELSE 0 
        END 
      WHERE 1=1; 
   INSERT INTO mjesto3 SELECT * FROM mjesto1 WHERE pbr < 20100; 
END PROCEDURE;

EXECUTE PROCEDURE genData(); 
UPDATE STATISTICS FOR TABLE mjesto1; 
UPDATE STATISTICS FOR TABLE mjesto2; 
UPDATE STATISTICS FOR TABLE mjesto3; 
UPDATE STATISTICS FOR TABLE mjestoInternac;

CREATE PROCEDURE brojRazlicitihVrijednostiAtributa() RETURNING INTEGER
	DEFINE temp integer;
	DEFINE rez integer;
	LET rez = 0;
	CREATE TABLE vrijednostiAtributa(
		vrijednost integer
	);
	FOREACH 
		SELECT pbr INTO temp FROM mjesto1
		IF NOT EXISTS (SELECT * FROM vrijednostiAtributa WHERE vrijednost = temp) THEN
			LET rez = rez + 1;
			INSERT INTO vrijednostiAtributa VALUES(temp);
		END IF;
	END FOREACH;
	DROP TABLE vrijednostiAtributa;
	RETURN rez;
END PROCEDURE;

EXECUTE PROCEDURE brojRazlicitihVrijednostiAtributa();

DROP PROCEDURE brojRazlicitihVrijednostiAtributa();


CREATE PROCEDURE brojRazlicitihVrijednostiAtributa() RETURNING INTEGER
	DEFINE temp integer;
	DEFINE rez integer;
	LET rez = 0;
	CREATE TABLE vrijednostiAtributa(
		vrijednost integer
	);
	FOREACH 
		SELECT pbr INTO temp FROM mjesto2
		IF NOT EXISTS (SELECT * FROM vrijednostiAtributa WHERE vrijednost = temp) THEN
			LET rez = rez + 1;
			INSERT INTO vrijednostiAtributa VALUES(temp);
		END IF;
	END FOREACH;
	DROP TABLE vrijednostiAtributa;
	RETURN rez;
END PROCEDURE;
			
EXECUTE PROCEDURE brojRazlicitihVrijednostiAtributa();			

DROP PROCEDURE brojRazlicitihVrijednostiAtributa();


CREATE PROCEDURE brojRazlicitihVrijednostiAtributa() RETURNING INTEGER
	DEFINE temp integer;
	DEFINE rez integer;
	LET rez = 0;
	CREATE TABLE vrijednostiAtributa(
		vrijednost integer
	);
	FOREACH 
		SELECT pbr INTO temp FROM mjestoInternac
		IF NOT EXISTS (SELECT * FROM vrijednostiAtributa WHERE vrijednost = temp) THEN
			LET rez = rez + 1;
			INSERT INTO vrijednostiAtributa VALUES(temp);
		END IF;
	END FOREACH;
	DROP TABLE vrijednostiAtributa;
	RETURN rez;
END PROCEDURE;
			
EXECUTE PROCEDURE brojRazlicitihVrijednostiAtributa();			

UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} * 
   FROM mjestoInternac 
   WHERE pbr BETWEEN 20200 AND 22200;

CREATE INDEX i1 ON mjestoInternac(pbr); 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} * 
   FROM mjestoInternac 
   WHERE pbr BETWEEN 20200 AND 22200; 
DROP INDEX i1; 
UPDATE STATISTICS FOR TABLE mjestoInternac; 

CREATE INDEX i1 ON mjestoInternac(pbr); 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} pbr 
   FROM mjestoInternac 
   WHERE pbr BETWEEN 20200 AND 22200; 
DROP INDEX i1; 
UPDATE STATISTICS FOR TABLE mjestoInternac; 

CREATE INDEX i1 ON mjestoInternac(brojStan); 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} * 
   FROM mjestoInternac 
   WHERE brojStan = 10200 AND oznDrz = 'gb'; 
DROP INDEX i1; 
UPDATE STATISTICS FOR TABLE mjestoInternac;

CREATE INDEX i1 ON mjestoInternac(brojStan); 
CREATE INDEX i2 ON mjestoInternac(oznDrz); 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} * 
   FROM mjestoInternac 
   WHERE brojStan = 10200 AND oznDrz = 'gb'; 
DROP INDEX i1; 
DROP INDEX i2; 
UPDATE STATISTICS FOR TABLE mjestoInternac;

CREATE INDEX i1 ON mjestoInternac(brojStan, oznDrz); 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} * 
   FROM mjestoInternac 
   WHERE brojStan = 10200 AND oznDrz = 'gb'; 
DROP INDEX i1; 
UPDATE STATISTICS FOR TABLE mjestoInternac;

CREATE INDEX i1 ON mjestoInternac(brojStan, pbr); 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} *  
   FROM mjestoInternac 
   WHERE brojStan = 10200 AND oznDrz = 'gb'; 
DROP INDEX i1; 
UPDATE STATISTICS FOR TABLE mjestoInternac;

CREATE INDEX i1 ON mjestoInternac(oznDrz, pbr); 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} * 
   FROM mjestoInternac 
   WHERE pbr = 20500; 
DROP INDEX i1; 
UPDATE STATISTICS FOR TABLE mjestoInternac;

CREATE INDEX i1 ON mjestoInternac(nazMjesto, pbr); 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} * 
   FROM mjestoInternac 
   WHERE pbr = 20500; 
DROP INDEX i1; 
UPDATE STATISTICS FOR TABLE mjestoInternac; 

CREATE INDEX i1 ON mjestoInternac(brojStan); 
CREATE INDEX i2 ON mjestoInternac(pbr); 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} * 
   FROM mjestoInternac 
   WHERE brojStan BETWEEN 10200 AND 10300 OR pbr BETWEEN 20000 AND 20200; 
DROP INDEX i1; 
DROP INDEX i2; 
UPDATE STATISTICS FOR TABLE mjestoInternac;

CREATE INDEX i1 ON mjestoInternac(brojStan); 
CREATE INDEX i2 ON mjestoInternac(pbr); 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} * 
   FROM mjestoInternac 
   WHERE brojStan BETWEEN 10000 AND 80000 OR pbr BETWEEN 82000 AND 90000; 
DROP INDEX i1; 
DROP INDEX i2; 
UPDATE STATISTICS FOR TABLE mjestoInternac; 

CREATE INDEX i1 ON mjestoInternac(brojStan); 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} * 
   FROM mjestoInternac 
   WHERE brojStan = 10200 OR oznDrz = 'gb'; 
DROP INDEX i1; 
UPDATE STATISTICS FOR TABLE mjestoInternac; 

UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} * 
   FROM mjestoInternac 
   ORDER BY nazMjesto;

CREATE INDEX i1 ON mjesto1(brojStan, nazMjesto); 
UPDATE STATISTICS FOR TABLE mjesto1; 
SELECT {+EXPLAIN} * 
   FROM mjesto1 
   WHERE brojStan BETWEEN 15000 AND 15100 
   ORDER BY brojStan; 
DROP INDEX i1; 
UPDATE STATISTICS FOR TABLE mjesto1;

CREATE INDEX i1 ON mjesto1(brojStan, nazMjesto); 
UPDATE STATISTICS FOR TABLE mjesto1; 
SELECT {+EXPLAIN} * 
   FROM mjesto1 
   WHERE brojStan BETWEEN 15000 AND 15100 
   ORDER BY brojStan DESC, nazMjesto DESC; 
DROP INDEX i1; 
UPDATE STATISTICS FOR TABLE mjesto1; 

CREATE INDEX i1 ON mjesto1(brojStan, nazMjesto); 
UPDATE STATISTICS FOR TABLE mjesto1; 
SELECT {+EXPLAIN} * 
   FROM mjesto1 
   WHERE brojStan BETWEEN 15000 AND 15100 
   ORDER BY brojStan DESC, nazMjesto ASC; 
DROP INDEX i1; 
UPDATE STATISTICS FOR TABLE mjesto1; 

CREATE INDEX i1 ON mjesto1(pbr); 
UPDATE STATISTICS FOR TABLE mjesto1; 
SELECT {+EXPLAIN} * 
   FROM mjesto1 
   ORDER BY pbr; 
DROP INDEX i1; 
UPDATE STATISTICS FOR TABLE mjesto1; 

UPDATE STATISTICS FOR TABLE mjesto1; 
UPDATE STATISTICS FOR TABLE mjesto2; 
SELECT {+EXPLAIN} * 
    FROM mjesto1  
         JOIN mjesto2 
           ON mjesto1.pbr = mjesto2.pbr;

UPDATE STATISTICS FOR TABLE mjesto1; 
UPDATE STATISTICS FOR TABLE mjesto2; 
SELECT {+EXPLAIN AVOID_EXECUTE} * 
    FROM mjesto1  
         JOIN mjesto2 
           ON mjesto1.pbr < mjesto2.pbr; 

UPDATE STATISTICS FOR TABLE mjesto1; 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} mjesto1.brojStan, mjestoInternac.brojStan   
    FROM mjesto1 
         JOIN mjestoInternac 
           ON mjestoInternac.pbr BETWEEN mjesto1.pbr AND mjesto1.pbr + 5;

CREATE INDEX i1 ON mjesto3(pbr); 
CREATE INDEX i2 ON mjestoInternac(pbr); 
UPDATE STATISTICS FOR TABLE mjesto3; 
UPDATE STATISTICS FOR TABLE mjestoInternac; 
SELECT {+EXPLAIN} * 
    FROM mjesto3  
         JOIN mjestoInternac 
           ON mjesto3.pbr = mjestoInternac.pbr; 
DROP INDEX i1; 

UPDATE STATISTICS FOR TABLE mjesto1; 
UPDATE STATISTICS FOR TABLE mjesto2; 
SELECT {+EXPLAIN} pbr 
  FROM mjestoInternac  
  UNION SELECT pbr FROM mjesto2;  -- union 

UPDATE STATISTICS FOR TABLE mjesto1; 
UPDATE STATISTICS FOR TABLE mjesto2; 
SELECT {+EXPLAIN}  
   pbr FROM mjestoInternac  
   UNION ALL SELECT pbr FROM mjesto2; -- bag union


DROP INDEX i2; 
UPDATE STATISTICS FOR TABLE mjesto3; 
UPDATE STATISTICS FOR TABLE mjestoInternac;

CLOSE DATABASE;
DROP DATABASE testOptim1;