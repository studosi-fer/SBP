CREATE DATABASE testBackup IN dbspace1 WITH LOG; 
DATABASE testBackup;
CREATE TABLE stoJeObavljeno ( 
   rbrZapis  INTEGER 
 , tekst     CHAR(16000) 
) EXTENT SIZE 10240 NEXT SIZE 10240;

SELECT MAX(rbrZapis) FROM stoJeObavljeno;

SELECT * FROM stoJeObavljeno;