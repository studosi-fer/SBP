EXECUTE PROCEDURE genAlter(200000); 

SELECT * FROM tableInfo 
   WHERE dbName = 'testdb' AND tabName IN ('osoba', 'mjesto'); 

SELECT * FROM tableExtentInfo 
   WHERE dbName = 'testdb' AND tabName IN ('osoba', 'mjesto') 
   ORDER BY offsetPage;
--
DELETE FROM mjesto;
DELETE FROM osoba;

SELECT * FROM tableInfo 
   WHERE dbName = 'testdb' AND tabName IN ('osoba', 'mjesto'); 

SELECT * FROM tableExtentInfo 
   WHERE dbName = 'testdb' AND tabName IN ('osoba', 'mjesto') 
   ORDER BY offsetPage;
--
EXECUTE PROCEDURE genAlter(200000); 

SELECT * FROM tableInfo 
   WHERE dbName = 'testdb' AND tabName IN ('osoba', 'mjesto'); 

SELECT * FROM tableExtentInfo 
   WHERE dbName = 'testdb' AND tabName IN ('osoba', 'mjesto') 
   ORDER BY offsetPage;

-- izvr�iti kao korisnik informix
--DATABASE sysadmin;
EXECUTE FUNCTION admin ('defragment', 'testdb:horvat.osoba'); 
EXECUTE FUNCTION admin ('defragment', 'testdb:horvat.mjesto');

DATABASE testdb;
SELECT * FROM tableInfo 
   WHERE dbName = 'testdb' AND tabName IN ('osoba', 'mjesto'); 

SELECT * FROM tableExtentInfo 
   WHERE dbName = 'testdb' AND tabName IN ('osoba', 'mjesto') 
   ORDER BY offsetPage;
--
SELECT * FROM tableExtentInfo 
   WHERE dbName = 'testdb' AND tabName IN ('osoba', 'mjesto') 
   ORDER BY offsetPage;

DROP TABLE mjesto;
DROP TABLE osoba;

--tema: Utjecaj veli�ine me�uspremnika na performance sustava

CREATE TABLE osoba ( 
    sifOsoba      INTEGER      NOT NULL  
  , imeOsoba      NCHAR(2450)  NOT NULL  
  , prezOsoba     NCHAR(2450)  NOT NULL 
  , pbrStan       INTEGER      NOT NULL 
  ) EXTENT SIZE 8 NEXT SIZE 8; 
  
CREATE TABLE mjesto ( 
    pbr           INTEGER     NOT NULL  
  , nazMjesto     NCHAR(20)   NOT NULL 
  ) EXTENT SIZE 8 NEXT SIZE 8;

EXECUTE PROCEDURE genAlter(20000); 

SELECT * FROM tableInfo 
   WHERE dbName = 'testdb' AND tabName = 'osoba'; 

CREATE PROCEDURE velikBrojCitanja(brojCiklusa INTEGER) 
   DEFINE i INTEGER; 
   DEFINE rez DECIMAL(10,2); 
   FOR i = 1 TO brojCiklusa 
      SELECT SUM(sifOsoba) INTO rez FROM osoba WHERE MOD(sifOsoba, 7) = 0; 
      SELECT AVG(LENGTH(imeOsoba)) INTO rez FROM osoba WHERE MOD(pbrStan, 3) = 2; 
      SELECT AVG(sifOsoba) INTO rez FROM osoba WHERE MOD(sifOsoba, 19) = 3; 
      SELECT SUM(LENGTH(imeOsoba)) INTO rez FROM osoba WHERE MOD(pbrStan, 13) = 7; 
   END FOR 
END PROCEDURE; 

SELECT * FROM mjesto; 
SELECT dbsname, tabname, pagreads, bufreads 
   FROM sysmaster:sysptprof 
   WHERE dbsname = 'testdb' AND tabname = 'mjesto';

EXECUTE PROCEDURE velikBrojCitanja(5); 
SELECT dbsname, tabname, pagreads, bufreads 
   FROM sysmaster:sysptprof 
   WHERE dbsname = 'testdb' AND tabname = 'osoba';

EXECUTE PROCEDURE velikBrojCitanja(5); 
SELECT dbsname, tabname, pagreads, bufreads 
   FROM sysmaster:sysptprof 
   WHERE dbsname = 'testdb' AND tabname = 'osoba';

EXECUTE PROCEDURE velikBrojCitanja(5); 
SELECT dbsname, tabname, pagreads, bufreads 
   FROM sysmaster:sysptprof 
   WHERE dbsname = 'testdb' AND tabname = 'osoba';
   
CLOSE DATABASE; 
DROP DATABASE testDb;  