CREATE FUNCTION najboljihN (n integer) 
   RETURNING CHAR(10) AS JMBAG, NCHAR(25) AS prezimeStudent, NCHAR(25) as imeStudent, DECIMAL(3,2) AS prosjek; 
   DEFINE p_JMBAG          LIKE student.JMBAG; 
   DEFINE p_imeStudent     LIKE student.imeStudent;    
   DEFINE p_prezimeStudent LIKE student.prezimeStudent;    
   DEFINE p_prosjek        DECIMAl(3,2); 
   DEFINE brojac           INTEGER; 
   LET brojac = 0; 
   FOREACH  
      SELECT student.JMBAG 
           , student.prezimeStudent 
           , student.imeStudent 
           , AVG(ocjena) 
        INTO p_JMBAG 
           , p_prezimeStudent 
           , p_imeStudent 
           , p_prosjek 
        FROM student, outer upisanPredmet 
        WHERE student.JMBAG = upisanPredmet.JMBAG 
        GROUP BY 1, 2, 3 
        ORDER BY 4 DESC, 2 ASC, 3 ASC 
      RETURN p_JMBAG, p_prezimeStudent, p_imeStudent, p_prosjek WITH RESUME;  
      LET brojac = brojac + 1; 
      IF brojac >= n THEN 
         EXIT FOREACH; 
      END IF  
   END FOREACH 
END FUNCTION;

EXECUTE FUNCTION najboljihN(10);