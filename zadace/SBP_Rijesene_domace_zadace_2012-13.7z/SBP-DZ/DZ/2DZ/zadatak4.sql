--objasnjenja od stranice 79 pa nadalje

--trebale bi se aktivirati greska -701, a zatim -703 
--jer su -701 i -702 u bloku, no ispisuje se popup samo kod -703
CREATE PROCEDURE test1 ()  
   DEFINE i SMALLINT;  
   ON EXCEPTION SET i 
      IF i IN (-702, -703) THEN  
         RAISE EXCEPTION -746, 0, 'Pogreska ' || i;  
      END IF 
   END EXCEPTION WITH RESUME  
   BEGIN  
      RAISE EXCEPTION -701; 
      RAISE EXCEPTION -702;  
   END  
   RAISE EXCEPTION -703;  
END PROCEDURE;

EXECUTE PROCEDURE test1();

--ispisuje se samo -702
CREATE PROCEDURE test2 ()  
   DEFINE i SMALLINT; 
   ON EXCEPTION SET i 
      IF i IN (-702, -703) THEN  
         RAISE EXCEPTION -746, 0, 'Pogreska ' || i;  
      END IF  
   END EXCEPTION WITH RESUME  
   RAISE EXCEPTION -701;  
   RAISE EXCEPTION -702;  
   RAISE EXCEPTION -703;  
END PROCEDURE; 

EXECUTE PROCEDURE test2();

-- procedura se prekida odmah nakon izvodenja -701
CREATE PROCEDURE test2nr ()  
   DEFINE i SMALLINT; 
   ON EXCEPTION SET i 
      IF i IN (-702, -703) THEN  
         RAISE EXCEPTION -746, 0, 'Pogreska ' || i;  
      END IF  
   END EXCEPTION
   RAISE EXCEPTION -701;  
   RAISE EXCEPTION -702;  
   RAISE EXCEPTION -703;  
END PROCEDURE; 

EXECUTE PROCEDURE test2nr();

-- ispise se SQL Error (-746): Druga
-- prvo se aktiviraju sve naredbe u bloku, a zatim one izvan bloka
CREATE PROCEDURE test3 ()  
   ON EXCEPTION IN (-703)  
      RAISE EXCEPTION -746, 0, 'Druga';  
   END EXCEPTION  
   ON EXCEPTION IN (-702)  
      RAISE EXCEPTION -746, 0, 'Prva';  
   END EXCEPTION  
   ON EXCEPTION IN (-701)  
      RAISE EXCEPTION -746, 0, 'Treca';  
   END EXCEPTION  
   BEGIN  
      ON EXCEPTION IN (-701)  
         RAISE EXCEPTION -702;  
      END EXCEPTION  
      ON EXCEPTION  
         RAISE EXCEPTION -703;  
      END EXCEPTION  
      RAISE EXCEPTION -701;  
   END  
END PROCEDURE;  

EXECUTE PROCEDURE test3();

-- ispise se SQL Error (-746): Treca jer je to vanjski blok

CREATE PROCEDURE test3p()  
   ON EXCEPTION IN (-703)  
      RAISE EXCEPTION -746, 0, 'Druga';  
   END EXCEPTION  
   ON EXCEPTION IN (-702)  
      RAISE EXCEPTION -746, 0, 'Prva';  
   END EXCEPTION  
   ON EXCEPTION IN (-701)  
      RAISE EXCEPTION -746, 0, 'Treca';  
   END EXCEPTION  
   BEGIN  
      ON EXCEPTION IN (-701)  
         RAISE EXCEPTION -702;  
      END EXCEPTION  
      ON EXCEPTION  
         RAISE EXCEPTION -703;  
      END EXCEPTION  
   END  
   RAISE EXCEPTION -701;    
END PROCEDURE;  

EXECUTE PROCEDURE test3p();