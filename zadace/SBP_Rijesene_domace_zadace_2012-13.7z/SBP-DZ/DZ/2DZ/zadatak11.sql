CREATE FUNCTION chkZaposlenUAkGodina (p_datumZaposlenOd LIKE nastavnik.datumZaposlenOd 
                                    , p_datumZaposlenDo LIKE nastavnik.datumZaposlenOd 
                                    , p_akGodina        LIKE predmetGrupa.akGodina) 
   RETURNING SMALLINT AS jeZaposlen; 
    
   DEFINE p_datumPocetakAkGodina DATE; 
   DEFINE p_datumKrajAkGodina    DATE; 
   LET p_datumPocetakAkGodina = MDY(10,1,p_akGodina); 
   LET p_datumKrajAkGodina = MDY(10,1,p_akGodina+1); 
   --ne smije biti zaposlen nakon po�etka akGodine + ne smije mu prestati radni odnos prije kraja akGodine 
    
   IF p_datumZaposlenOd > p_datumPocetakAkGodina OR p_datumZaposlenDo IS NOT NULL  
      AND p_datumZaposlenDo < p_datumKrajAkGodina THEN 
      RETURN 0; 
   END IF 
    
   RETURN 1; 
END FUNCTION; -- chkZaposlenUAkGodina 
--spre�ava evidenciju nastavnika-predava�a u predmetGrupa ako nastavnik nije bio zaposlen te akademske godine 
CREATE PROCEDURE chkPredmetGrupa (p_akGodina       LIKE predmetGrupa.akGodina 
                                , p_sifNastavnik   LIKE predmetGrupa.sifNastavnik) 
    
   DEFINE p_datumZaposlenOd   LIKE nastavnik.datumZaposlenOd; 
   DEFINE p_datumZaposlenDo   LIKE nastavnik.datumZaposlenDo; 
       
   SELECT datumZaposlenOd 
       ,  datumZaposlenDo 
     INTO p_datumZaposlenOd 
        , p_datumZaposlenDo 
     FROM nastavnik 
    WHERE sifNastavnik = p_sifNastavnik;      
    
   IF chkzaposlenUAkGodina (p_datumZaposlenOd, p_datumZaposlenDo, p_akGodina) = 0 THEN 
      RAISE EXCEPTION -746, 0, 'Djelatnik ne mo�e izvoditi nastavu u ak. godini ' || p_akGodina || '/' || 
(p_akGodina+1) + '.'; 
   END IF 
END PROCEDURE; -- chkPredmetGrupa 