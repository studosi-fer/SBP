CREATE PROCEDURE javiPogresku () 
   RAISE EXCEPTION -746,0, 'Izmjena nije dopustena'; 
END PROCEDURE; 
CREATE TRIGGER izmijeniUpisanPredmet 
   UPDATE ON upisanpredmet 
   REFERENCING OLD AS oldupisanpredmet 
   FOR EACH ROW 
        WHEN (oldupisanpredmet.ocjena = 1) 
           (EXECUTE PROCEDURE javiPogresku() 
    );

SELECT * FROM upisanPredmet WHERE ocjena = 1;
UPDATE upisanPredmet SET ocjena = 2 WHERE ocjena = 1;