CREATE FUNCTION prosjekOcjena()  
   RETURNING DECIMAL(3,2) 
   DEFINE GLOBAL pozvanProsjek CHAR(1) DEFAULT NULL;     
   IF pozvanProsjek IS NULL THEN 
      LET pozvanProsjek = 'Y'; 
      RETURN (SELECT AVG(ocjena) FROM upisanPredmet WHERE ocjena > 1); 
   ELSE 
      RETURN NULL; 
   END IF; 
END FUNCTION;

CREATE FUNCTION brojNepristup()  
   RETURNING INTEGER 
   DEFINE GLOBAL pozvanNepristup CHAR(1) DEFAULT NULL;     
   IF pozvanNepristup IS NULL THEN 
      LET pozvanNepristup = 'Y'; 
      RETURN (SELECT COUNT(*) FROM student WHERE JMBAG NOT IN  
                       (SELECT JMBAG FROM upisanPredmet WHERE ocjena >1)); 
   ELSE 
      RETURN NULL; 
   END IF; 
END FUNCTION; 


CREATE FUNCTION vrijemePrvogPoziva()  
   RETURNING DATETIME YEAR TO FRACTION(3), DATETIME YEAR TO FRACTION(3); 
   DEFINE GLOBAL t1 DATETIME YEAR TO FRACTION(3) DEFAULT NULL; 
   DEFINE t DATETIME YEAR TO FRACTION(3);  
   IF t1 IS NULL THEN 
      LET t1 = CURRENT; 
   END IF 
   LET t = CURRENT; 
   RETURN t, t1; 
END FUNCTION; 

EXECUTE FUNCTION vrijemePrvogPoziva();
EXECUTE FUNCTION prosjekOcjena();
EXECUTE FUNCTION brojNepristup();

EXECUTE FUNCTION prosjekOcjena();
EXECUTE FUNCTION brojNepristup();
EXECUTE FUNCTION vrijemePrvogPoziva();