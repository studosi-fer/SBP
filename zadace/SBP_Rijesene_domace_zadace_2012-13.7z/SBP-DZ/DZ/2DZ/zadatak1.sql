CREATE PROCEDURE rshift ( p_niz CHAR (100), n SMALLINT ) 
        RETURNING CHAR(100); 
   IF n > 0 THEN 
           LET n = n-1; 
           LET p_niz = " " || rshift (p_niz, n); 
   END IF 
   RETURN p_niz; 
END PROCEDURE;

EXECUTE PROCEDURE rshift('Test', 1);
EXECUTE PROCEDURE rshift('Test', 10);