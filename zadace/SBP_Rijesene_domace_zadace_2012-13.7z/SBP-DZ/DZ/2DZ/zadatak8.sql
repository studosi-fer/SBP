CREATE FUNCTION prijepisOcjena(p_JMBAG LIKE student.JMBAG) 
   RETURNING INTEGER AS sifPredmet, NCHAR(60) AS nazPredmet, DECIMAL (4,1) AS ECTSBod, SMALLINT AS ocjena,  
             DATE AS datumOcjena; 
    
   DEFINE p_sifPredmet  LIKE upisanPredmet.sifPredmet ; 
   DEFINE p_nazPredmet  LIKE predmet.nazPredmet       ; 
   DEFINE p_ECTSBod     LIKE predmet.ECTSBod          ; 
   DEFINE p_ocjena      LIKE upisanPredmet.ocjena     ; 
   DEFINE p_datumOcjena LIKE upisanPredmet.datumOcjena; 
   DEFINE i smallint ; 
    
   IF NOT EXISTS (SELECT * FROM student WHERE JMBAG = p_JMBAG) THEN 
      RAISE EXCEPTION -746, 0, 'Ne postoji student s JMBAG-om ' || p_JMBAG || '.'; 
   END IF 
   LET i = 0; 
   FOREACH 
      SELECT upisanPredmet.sifPredmet 
           , predmet.nazPredmet 
           , predmet.ECTSBod 
           , upisanPredmet.ocjena 
           , upisanPredmet.datumOcjena 
        INTO p_sifPredmet 
           , p_nazPredmet 
           , p_ECTSBod 
           , p_ocjena 
           , p_datumOcjena 
        FROM upisanPredmet, predmet 
       WHERE upisanPredmet.sifPredmet = predmet.sifPredmet  
         AND upisanPredmet.JMBAg = p_JMBAG 
         AND upisanPredmet.ocjena > 1 
         ORDER BY nazPredmet 
      RETURN p_sifPredmet, p_nazPredmet, p_ECTSBod, p_ocjena, p_datumOcjena WITH RESUME; 
      LET i= i+1; 
   END FOREACH      
   IF i=0 THEN 
      RAISE EXCEPTION -746, 0, 'Student s JMBAG-om ' || p_JMBAG || ' nije polo�io nijedan predmet.'; 
   END IF    
END FUNCTION;

EXECUTE FUNCTION prijepisOcjena ('0555000099');
EXECUTE FUNCTION prijepisOcjena ('0555000032');
EXECUTE FUNCTION prijepisOcjena ('0555000597');