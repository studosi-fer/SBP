CREATE PROCEDURE drugiDioMjeseca () 
 IF DAY (TODAY) > 15 THEN 
    RAISE EXCEPTION -746, 0, 'Drugi dio mjeseca'; 
 END IF 
END PROCEDURE;

EXECUTE PROCEDURE drugiDioMjeseca();