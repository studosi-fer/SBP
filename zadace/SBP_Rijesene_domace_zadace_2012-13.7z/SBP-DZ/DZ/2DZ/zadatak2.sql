CREATE PROCEDURE pripremiIspisOrgjed (ulazSifOrgjed LIKE orgjed.sifOrgJed 
                                    , razina SMALLINT)  
  DEFINE p_sifOrgjed LIKE orgjed.sifOrgjed; 
  INSERT INTO ispisOrgjed VALUES (0 , razina , ulazSifOrgjed , (SELECT nazOrgjed FROM orgjed WHERE sifOrgjed = ulazSifOrgjed) ); 
   FOREACH 
      SELECT sifOrgjed INTO p_sifOrgjed FROM orgjed
         WHERE sifNadOrgjed = ulazSifOrgjed 
         CALL pripremiIspisOrgjed (p_sifOrgjed, razina + 1); 
   END FOREACH 
END PROCEDURE; 

CREATE PROCEDURE ispisiOrgjed(ulazSifOrgjed LIKE orgjed.sifOrgJed) 
   RETURNING CHAR(120) AS nazOrgJed; 
   DEFINE p_nazOrgJed   LIKE orgJed.nazOrgJed; 
   BEGIN 
      ON EXCEPTION 
         DELETE FROM ispisOrgjed; 
      END EXCEPTION WITH RESUME; 
      CREATE TEMP TABLE ispisOrgjed ( 
           rbrCvor      SERIAL    NOT NULL  
         , razina       SMALLINT  NOT NULL  
         , sifOrgjed    INTEGER   NOT NULL 
         , nazOrgjed    NCHAR(60) NOT NULL) WITH NO LOG; 
   END 
   EXECUTE PROCEDURE pripremiIspisOrgjed (ulazSifOrgjed, 0); 
   FOREACH 
      SELECT RSHIFT(nazOrgjed, razina*3)  
      INTO p_nazOrgjed 
        FROM ispisOrgjed 
      ORDER BY rbrCvor 
      RETURN p_nazOrgjed WITH RESUME; 
   END FOREACH 
END PROCEDURE;

EXECUTE PROCEDURE ispisiOrgjed(9996);