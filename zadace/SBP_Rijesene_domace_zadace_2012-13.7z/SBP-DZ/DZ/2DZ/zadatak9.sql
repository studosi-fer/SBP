CREATE PROCEDURE ocjObrane ( p_JMBAG int, 
                             p_datumPrijava date) 
 RETURNING SMALLINT; 
   DEFINE p_ocjObrane SMALLINT; 
   DEFINE cnt SMALLINT; 
   
   LET cnt = (SELECT COUNT (*) FROM diplom 
       WHERE JMBAG = p_JMBAG 
             AND datumPrijava = p_datumPrijava); 
   IF cnt = 0 THEN 
       RETURN NULL; 
   END IF 
  
   LET cnt = (SELECT COUNT(*) FROM diplom 
                  WHERE JMBAG = p_JMBAG 
                    AND datumPrijava = p_datumPrijava 
                    AND ocjenaRad = 1) + 
             (SELECT COUNT(*) FROM dipkom 
                  WHERE JMBAG = p_JMBAG 
                    AND datumPrijava = p_datumPrijava 
                    AND ocjenaUsm = 1); 
   IF cnt > 0 THEN 
      RETURN 1; 
   END IF 
  
   LET cnt = (SELECT COUNT(*) FROM diplom 
                  WHERE JMBAG = p_JMBAG 
                    AND datumPrijava = p_datumPrijava 
                    AND ocjenaRad IS NOT NULL) + 
             (SELECT COUNT(*) FROM dipkom 
                  WHERE JMBAG = p_JMBAG 
                    AND datumPrijava = p_datumPrijava 
                    AND ocjenaUsm IS NOT NULL); 
   IF cnt < 4 THEN 
      RETURN 0; 
   END IF
   SELECT ROUND (AVG (ocjenaUsm),0) INTO p_ocjObrane FROM dipkom 
       WHERE JMBAG = p_JMBAG 
             AND datumPrijava = p_datumPrijava; 
   RETURN p_ocjObrane; 
END PROCEDURE;

EXECUTE PROCEDURE ocjObrane(0555004484,'05.04.2008');