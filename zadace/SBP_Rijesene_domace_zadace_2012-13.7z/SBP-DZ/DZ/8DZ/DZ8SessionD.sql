DATABASE testConcurr;
SELECT DBINFO ('sessionid') AS currentSessionId FROM systables WHERE tabid = 1; 

--tocka 3
BEGIN WORK;
SET LOCK MODE TO WAIT;



UPDATE racun SET iznos=8 
WHERE brRacun=4 ;





UPDATE racun SET iznos=3 
WHERE brRacun=5;
ROLLBACK WORK;