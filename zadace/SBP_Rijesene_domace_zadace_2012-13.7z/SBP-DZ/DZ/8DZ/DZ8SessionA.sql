DATABASE testConcurr;
SELECT DBINFO ('sessionid') AS currentSessionId FROM systables WHERE tabid = 1; 

SET LOCK MODE TO WAIT;
BEGIN WORK;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SELECT iznos FROM racun 
  WHERE brRacun = 95; 
  
SELECT iznos FROM racun 
  WHERE brRacun = 96; 
  
ROLLBACK WORK;

-- tocka 2
BEGIN WORK; 
UPDATE racun SET iznos = 1000.00 
   WHERE brRacun = 50;

ROLLBACK WORK;
-- tocka 3
BEGIN WORK;
SET LOCK MODE TO WAIT;
UPDATE racun SET iznos=5 
WHERE brRacun=1;



UPDATE racun SET iznos=9 
WHERE brRacun=5 ;

UPDATE racun SET iznos=2 
WHERE brRacun=6;



ROLLBACK WORK;