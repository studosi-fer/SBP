DATABASE testConcurr;
SELECT DBINFO ('sessionid') AS currentSessionId FROM systables WHERE tabid = 1; 

SET LOCK MODE TO WAIT;
BEGIN WORK;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SELECT iznos FROM racun 
  WHERE brRacun BETWEEN 94 AND 98;
UPDATE racun SET iznos = 1100.00 
  WHERE brRacun = 96 ;
  
ROLLBACK WORK;

-- tocka 2
BEGIN WORK; 
SET LOCK MODE TO NOT WAIT; 
UPDATE racun SET iznos = 1000.00 
   WHERE brRacun = 50;

SET LOCK MODE TO WAIT 3; 
UPDATE racun SET iznos = 1000.00 
   WHERE brRacun = 50; 

SET LOCK MODE TO WAIT; 
UPDATE racun SET iznos = 1000.00 
   WHERE brRacun = 50;

ROLLBACK WORK;
-- tocka 3
BEGIN WORK;
SET LOCK MODE TO WAIT;

UPDATE racun SET iznos=6 
WHERE brRacun=2;



UPDATE racun SET iznos=1 
WHERE brRacun=6 ;


UPDATE racun SET iznos=4 
WHERE brRacun=4;

ROLLBACK WORK;