DATABASE testConcurr;
SELECT DBINFO ('sessionid') AS currentSessionId FROM systables WHERE tabid = 1; 

SET ISOLATION TO DIRTY READ; 
SELECT racun.brRacun, sysmaster:rowlocks.*  
  FROM racun, sysmaster:rowlocks 
  WHERE racun.rowid = sysmaster:rowlocks.rowidlocked 
    AND tabname = 'racun';
	
SET ISOLATION TO DIRTY READ; 
SELECT racun.brRacun, sysmaster:rowlocks.*  
  FROM racun, sysmaster:rowlocks 
  WHERE racun.rowid = sysmaster:rowlocks.rowidlocked 
    AND sysmaster:rowlocks. sidIsWaiting IS NOT NULL 
    AND tabname = 'racun';