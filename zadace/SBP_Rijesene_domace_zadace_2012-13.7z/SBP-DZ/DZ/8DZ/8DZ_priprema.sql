CREATE database testConcurr IN dbspace1 WITH LOG; 

CREATE TABLE racun ( 
    brRacun       INTEGER       NOT NULL  
  , vlasnik       NCHAR(100)    NOT NULL  
  , iznos         DECIMAL(10,2) NOT NULL 
  , PRIMARY KEY (brRacun) CONSTRAINT pkRacun 
) EXTENT SIZE 128 NEXT SIZE 128 LOCK MODE ROW; 

CREATE PROCEDURE genRacun(brojGeneriranih INTEGER) 
   DEFINE i integer; 
   FOR i = 1 TO brojGeneriranih 
      INSERT INTO racun VALUES ( 
          i, 'Vlasnik racuna ' || i, MOD(i, 20)*100 + MOD(i, 2)*50); 
   END FOR 
END PROCEDURE; 

EXECUTE PROCEDURE genRacun(1000);
CLOSE DATABASE;
-- obavit u bazi sysmaster
DATABASE sysmaster;

CREATE VIEW rowlocks ( 
        sid 
      , tabName 
      , rowidLocked 
      , locktype 
      , sidIsWaiting) 
  AS SELECT sesslocker.sid 
      , syslocks.tabname 
      , syslocks.rowidlk 
      , syslocks.type 
      , syslocks.waiter 
      FROM syslocks 
      JOIN syssessions sesslocker 
        ON syslocks.owner = sesslocker.sid 
      WHERE dbsname <> 'sysmaster' 
        AND rowidlk <> 0; 

