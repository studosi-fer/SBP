DATABASE testConcurr;
SELECT DBINFO ('sessionid') AS currentSessionId FROM systables WHERE tabid = 1; 
--tocka 3
BEGIN WORK;
SET LOCK MODE TO WAIT;


UPDATE racun SET iznos=7 
WHERE brRacun=3;




UPDATE racun SET iznos=3 
WHERE brRacun=2 ;


ROLLBACK WORK;