-- UVOD

UPDATE STATISTICS DROP DISTRIBUTIONS;  -- unistiti eventualno postoje�e histograme

ALTER TABLE mjesto1 ADD brojLuka INTEGER DEFAULT 0 NOT NULL;

UPDATE mjesto1 
  SET brojLuka =
    CASE 
       WHEN MOD(pbr, 13) = 0 THEN 1
       WHEN MOD(pbr, 23) = 0 THEN 2
       WHEN MOD(pbr, 31) = 0 THEN 3
       WHEN MOD(pbr, 127) = 0 THEN 4
       WHEN MOD(pbr, 313) = 0 THEN 5
       WHEN MOD(pbr, 1777) = 0 THEN 6
       WHEN MOD(pbr, 6823) = 0 THEN 7
       WHEN MOD(pbr, 7919) = 0 THEN 8
       WHEN pbr = 30000 THEN 9
       ELSE 0
     END
   WHERE 1=1;

SELECT brojLuka, COUNT(*) brojntorki
  FROM mjesto1 
  GROUP BY brojluka
  ORDER BY brojLuka;


UPDATE STATISTICS FOR TABLE mjesto1;
SELECT nrows FROM systables WHERE tabname = 'mjesto1';


CREATE INDEX i1 ON mjesto1 (brojLuka);
UPDATE STATISTICS FOR TABLE mjesto1;
SELECT colmin, colmax FROM syscolumns WHERE colname = 'brojluka';
SELECT levels, nunique FROM sysindexes WHERE idxname = 'i1';
DROP INDEX i1;
UPDATE STATISTICS FOR TABLE mjesto1;
-- uklanjanje podataka iz rje�nika podataka o min i max vrijednosti atributa brojluka
UPDATE syscolumns SET colmin = NULL, colmax = NULL where colname = 'brojluka';


UPDATE STATISTICS HIGH FOR TABLE mjesto1(brojLuka);
SELECT * FROM sysdistrib;
UPDATE STATISTICS DROP DISTRIBUTIONS;



-- TEMA: utjecaj dostupnosti statisti�kih podataka na procjenu broja n-torki u rezultatu operacije relacijske algebre

-- 1.a) -------------

UPDATE STATISTICS DROP DISTRIBUTIONS; -- unistiti eventualno postoje�e histograme
UPDATE STATISTICS FOR TABLE mjesto1;
   -- gdje su relevantni statisti�ki podaci?
   SELECT nrows FROM systables WHERE tabname = 'mjesto1';

SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * FROM mjesto1
   WHERE brojLuka = 8;
SELECT * FROM mjesto1
   WHERE brojLuka > 5;
SET EXPLAIN OFF;



-- 1.b) -------------

CREATE INDEX i1 ON mjesto1 (brojLuka);
UPDATE STATISTICS FOR TABLE mjesto1 DROP DISTRIBUTIONS; -- unistiti histograme za relaciju mjesto1
   -- gdje su relevantni statisti�ki podaci?
   SELECT levels, nunique FROM sysindexes WHERE idxname = 'i1';
   SELECT colmin, colmax FROM syscolumns WHERE colname = 'brojluka'; 
    -- uo�iti: min(brojLuka, mjesto1)=1,  max(brojLuka, mjesto1)=8. Zasto ne 0 i 9?

SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * FROM mjesto1
   WHERE brojLuka = 8;
SELECT * FROM mjesto1
   WHERE brojLuka > 5;
SET EXPLAIN OFF;
DROP INDEX i1;
UPDATE STATISTICS FOR TABLE mjesto1 DROP DISTRIBUTIONS;




-- 1.c) -------------

UPDATE STATISTICS HIGH FOR TABLE mjesto1(brojLuka);
   -- gdje su relevantni statisti�ki podaci?
   SELECT * FROM sysdistrib;

SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * FROM mjesto1
   WHERE brojLuka = 8;
SELECT * FROM mjesto1
   WHERE brojLuka > 5;
SET EXPLAIN OFF;
UPDATE STATISTICS FOR TABLE mjesto1 DROP DISTRIBUTIONS;



-- TEMA: utjecaj procjene veli�ine medurezultata na izbor plana izvrsavanja upita 

-- 2.a) -------------

CREATE INDEX i1 ON mjesto1(brojLuka);
CREATE INDEX i2 ON mjesto2(pbr);
UPDATE STATISTICS FOR TABLE mjesto1;
UPDATE STATISTICS FOR TABLE mjesto2;
UPDATE STATISTICS HIGH FOR TABLE mjesto1(brojLuka);
SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * FROM mjesto1, mjesto2
   WHERE mjesto1.pbr = mjesto2.pbr
   AND brojLuka > 1;
SET EXPLAIN OFF;
DROP INDEX i1;
DROP INDEX i2;
UPDATE STATISTICS FOR TABLE mjesto1 DROP DISTRIBUTIONS;
UPDATE STATISTICS FOR TABLE mjesto2 DROP DISTRIBUTIONS;


-- 2.b) -------------

CREATE INDEX i1 ON mjesto1(brojLuka);
CREATE INDEX i2 ON mjesto2(pbr);
UPDATE STATISTICS FOR TABLE mjesto1;
UPDATE STATISTICS FOR TABLE mjesto2;
UPDATE STATISTICS HIGH FOR TABLE mjesto1(brojLuka);
SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * FROM mjesto1, mjesto2
   WHERE mjesto1.pbr = mjesto2.pbr
   AND brojLuka <= 1;
SET EXPLAIN OFF;
DROP INDEX i1;
DROP INDEX i2;
UPDATE STATISTICS FOR TABLE mjesto1 DROP DISTRIBUTIONS;
UPDATE STATISTICS FOR TABLE mjesto2 DROP DISTRIBUTIONS;


-- 2.c) -------------

CREATE INDEX i1 ON mjesto1(brojLuka);
CREATE INDEX i2 ON mjesto2(pbr);
UPDATE STATISTICS FOR TABLE mjesto1 DROP DISTRIBUTIONS;
UPDATE STATISTICS FOR TABLE mjesto2;
SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * FROM mjesto1, mjesto2
   WHERE mjesto1.pbr = mjesto2.pbr
   AND brojLuka > 1;
SET EXPLAIN OFF;
DROP INDEX i1;
DROP INDEX i2;
UPDATE STATISTICS FOR TABLE mjesto1 DROP DISTRIBUTIONS;
UPDATE STATISTICS FOR TABLE mjesto2 DROP DISTRIBUTIONS;


-- 2.d) -------------

CREATE INDEX i1 ON mjesto1(brojLuka);
CREATE INDEX i2 ON mjesto2(pbr);
UPDATE STATISTICS FOR TABLE mjesto1 DROP DISTRIBUTIONS;
UPDATE STATISTICS FOR TABLE mjesto2;
SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * FROM mjesto1, mjesto2
   WHERE mjesto1.pbr = mjesto2.pbr
   AND brojLuka <= 1;
SET EXPLAIN OFF;
DROP INDEX i1;
DROP INDEX i2;
UPDATE STATISTICS FOR TABLE mjesto1 DROP DISTRIBUTIONS;
UPDATE STATISTICS FOR TABLE mjesto2 DROP DISTRIBUTIONS;










-- TEMA: procjena broja n-torki u rezultatu selekcije sa slozenim uvjetima 


CREATE TABLE mjesto (
  pbr            INTEGER     NOT NULL 
, nazMjesto      NCHAR(50)   NOT NULL 
) EXTENT SIZE 1000 NEXT SIZE 1000;

CREATE TABLE stud (
  mbr            INTEGER     NOT NULL 
, imeStud        NCHAR(80)   NOT NULL 
, prezStud       NCHAR(80)   NOT NULL 
, pbrStan        INTEGER     NOT NULL
, datRod         DATE        NOT NULL
, spol           CHAR(1)     NOT NULL
, vrZdravOsig    INTEGER     NOT NULL
) EXTENT SIZE 5000 NEXT SIZE 5000;

CREATE TABLE ispit ( 
  mbrStud        INTEGER     NOT NULL 
, sifPred        INTEGER     NOT NULL 
, sifNastavnik   INTEGER     NOT NULL 
, datIspit       DATE        NOT NULL 
, ocjena         SMALLINT    NOT NULL 
) EXTENT SIZE 5000 NEXT SIZE 5000;


CREATE PROCEDURE genDataDrugiDio ()
   DEFINE i, j, k, mbr, ocjena, brIsp INTEGER;
   DELETE FROM mjesto;
   DELETE FROM stud;
   DELETE FROM ispit;
   CALL srand(1234);
   LET mbr = 1000;
   LET brIsp = 0;
   FOR i = 10001 TO 11000
      INSERT INTO mjesto 
        VALUES(i
             , genNiz(2 + MOD(rand(), 12))); 
      FOR j = 1 TO MOD(rand(), 10) + 1
         LET mbr = mbr + 1;
         IF mbr > 6000 THEN
            EXIT FOR;
         END IF; 
         INSERT INTO stud 
            VALUES(mbr
                 , genNiz(2 + MOD(rand(), 12))
                 , genNiz(2 + MOD(rand(), 12))
                 , i
                 , MDY(MOD(rand(), 12) + 1, MOD(rand(), 28) + 1, MOD(rand(), 3) + 1982)
                 , CASE MOD(rand(), 2) WHEN 0 THEN 'M' ELSE 'Z' END
                 , MOD(rand(), 3) + 1
                 );
         FOR k = 1 TO MOD(rand(), 40) + 1
            LET ocjena = MOD(rand(), 66);
            LET brIsp = brIsp + 1;
            IF brIsp > 100000 THEN
               EXIT FOR;
            END IF; 
            INSERT INTO ispit 
               VALUES(mbr
                    , MOD(rand(), 200) + 100
                    , MOD(rand(), 50) + 100
                    , MDY(MOD(rand(), 12) + 1, MOD(rand(), 28) + 1, MOD(rand(), 4) + 2005)
                    , CASE 
                         WHEN ocjena BETWEEN 0 AND 15 THEN 1
                         WHEN ocjena BETWEEN 16 AND 25 THEN 2
                         WHEN ocjena BETWEEN 26 AND 40 THEN 3
                         WHEN ocjena BETWEEN 41 AND 55 THEN 4
                         WHEN ocjena BETWEEN 56 AND 65 THEN 5
                    END
                    );
         END FOR
      END FOR
   END FOR
END PROCEDURE;

EXECUTE PROCEDURE genDataDrugiDio();
UPDATE STATISTICS FOR TABLE mjesto;
UPDATE STATISTICS FOR TABLE stud;
UPDATE STATISTICS FOR TABLE ispit;



-- 3.a) -------------

CREATE INDEX i1 ON ispit(ocjena);
CREATE INDEX i2 ON ispit(datIspit);
UPDATE STATISTICS FOR TABLE ispit DROP DISTRIBUTIONS;
SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * FROM ispit
   WHERE ocjena = 2
     AND datIspit = '16.04.2008';
SET EXPLAIN OFF;
DROP INDEX i1;
DROP INDEX i2;
UPDATE STATISTICS FOR TABLE ispit;


-- 3.b) -------------

CREATE INDEX i1 ON ispit(ocjena);
CREATE INDEX i2 ON ispit(sifNastavnik);
UPDATE STATISTICS FOR TABLE ispit DROP DISTRIBUTIONS;
SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * FROM ispit
   WHERE sifNastavnik <= 120
     AND ocjena = 2;
SET EXPLAIN OFF;
DROP INDEX i1;
DROP INDEX i2;
UPDATE STATISTICS FOR TABLE ispit;


-- 3.c) -------------

CREATE INDEX i1 ON stud(spol);
CREATE INDEX i2 ON stud(vrZdravOsig);
UPDATE STATISTICS FOR TABLE stud DROP DISTRIBUTIONS;
SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * FROM stud
   WHERE spol = 'Z' 
      OR vrZdravOsig = 2;
SET EXPLAIN OFF;
DROP INDEX i1;
DROP INDEX i2;
UPDATE STATISTICS FOR TABLE stud;


-- 3.d) -------------

CREATE INDEX i1 ON ispit(ocjena);
CREATE INDEX i2 ON ispit(sifNastavnik);
UPDATE STATISTICS FOR TABLE ispit DROP DISTRIBUTIONS;
SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * FROM ispit
   WHERE ocjena <> 1
      OR sifNastavnik = 120;
SET EXPLAIN OFF;
DROP INDEX i1;
DROP INDEX i2;
UPDATE STATISTICS FOR TABLE ispit;



-- TEMA: heuristi�ka optimizacija 

-- 4.a) -------------

UPDATE STATISTICS HIGH FOR TABLE mjesto;
UPDATE STATISTICS HIGH FOR TABLE stud;
UPDATE STATISTICS HIGH FOR TABLE ispit;
SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * 
   FROM ispit
      , stud 
      , mjesto 
   WHERE mjesto.pbr = stud.pbrStan 
     AND stud.mbr = ispit.mbrStud 
     AND mjesto.pbr = 10805
     AND ispit.ocjena = 1;
SET EXPLAIN OFF;


-- 4.b) -------------

UPDATE STATISTICS HIGH FOR TABLE mjesto;
UPDATE STATISTICS HIGH FOR TABLE stud;
UPDATE STATISTICS HIGH FOR TABLE ispit;
SET EXPLAIN FILE TO 'c:/tmp/plan.out';
SET EXPLAIN ON;
SELECT * 
   FROM ispit
      , stud 
      , mjesto 
   WHERE mjesto.pbr = stud.pbrStan 
     AND stud.mbr = ispit.mbrStud 
     AND (sifPred = 145 OR sifNastavnik = 120);
SET EXPLAIN OFF;


